using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class VictoryMenu : MonoBehaviour{

    public GameObject victoryPanel;
    private bool isVictory = false;
    
    private void Update() {
        if (Input.GetKeyDown(KeyCode.Escape)) {
            if (isVictory) {
                loadMainMenu();
            }
        }
    }

    public void Victory() {
        victoryPanel.SetActive(true);
        Time.timeScale = 0f;
        isVictory = true;
    }

    public void newGame() {
        victoryPanel.SetActive(false);
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenuScene");
        SceneManager.LoadScene("Gamescene");
    }

    public void loadMainMenu() {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenuScene");
    }

    public bool getIsVictory() {
        return isVictory;
    }
}
