using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Room{
    private float x;
    private float y;
    private float width;
    private float height;
    private int[,] pos;
    private int type;
    private bool visited;

    public Room(float _x, float _y, float _width, float _height){
        x = _x;
        y = _y;
        width = _width;
        height = _height;
        pos = new int[(int)width,(int)height];
        for(int i = 0; i < width; i++){
            for(int j = 0; j < height; j++){
                pos[i, j] = 1;
            }
        }
        visited = false;
    }

    public void setRoomDim(float newWidth, float newHeight){
        width = newWidth;
        height = newHeight;
        pos = new int[(int)width,(int)height];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                pos[i, j] = 1;
            }
        }
    }

    public void setWidth(float newWidth)
    {
        width = newWidth;
    }

    public float getWidth(){
        return width;
    }

    public void setHeight(float newHeight){
        height = newHeight;
    }

    public float getHeight(){
        return height;
    }

    public void setX(float newX){
        x = newX;
    }

    public float getX(){
        return x;
    }

    public void setY(float newY) {
        y = newY;
    }

    public float getY() {
        return y;
    }

    public void setPos(int x, int y, int val) {
        pos[x,y] = val;
    }

    public int getPos(int x, int y) {
        return pos[x,y];
    }

    public int[,] getPosMatrix() {
        return pos;
    }

    public void setType(int newType){
        type = newType;
    }

    public int getType(){ 
        return type; 
    }

    public void setVisited(bool newVisited) {
        visited = newVisited;
    }

    public bool getVisited() {
        return visited;
    }

}