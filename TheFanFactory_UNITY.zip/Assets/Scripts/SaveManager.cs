using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public static class SaveManager {

    private static string savePath = Application.persistentDataPath + "/savefile.json";

    public static void SaveGame(SaveData data) {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(savePath, json);
    }

    public static SaveData LoadGame() {
        if (File.Exists(savePath)) {
            string json = File.ReadAllText(savePath);
            return JsonUtility.FromJson<SaveData>(json);
        } else {
            return new SaveData();
        }
    }

    public static void DeleteSave() {
        if (File.Exists(savePath)) {
            File.Delete(savePath);
        }
    }
}