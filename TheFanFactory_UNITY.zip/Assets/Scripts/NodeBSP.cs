using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class NodeBSP{

    private Chamber room;
    private NodeBSP leftNode, rightNode;
    private NodeBSP root;
    private NodeBSP father;
    private int side;
    private List<Corridor> corridors = new List<Corridor>();

    // Node creation method
    public NodeBSP(Chamber area){
        room = area;
    }

    public void split(int numIter, int nowIter, List<int> div){

        if(nowIter >= numIter){
            return;
        }

        if(root == null) {
            root = this;
            div = new List<int>();
            for(int i = 0; i < numIter; i++) {
                div.Add(RandNumberGen.GetRandomNumber(45, 56));
            }
        }

        int dir = nowIter%2;

        if(dir == 0){ // Split horizontally
            int newWidth = (int)(room.getWidth() * (float)((float)div[nowIter] / (float)100));

            leftNode = new NodeBSP(new Chamber(room.getX(), room.getY(), newWidth, room.getHeight()));
            rightNode = new NodeBSP(new Chamber(room.getX() + newWidth, room.getY(), room.getWidth() - newWidth, room.getHeight()));

        }
        else{ // Split vertically
            int newHeight = (int)(room.getHeight() * (float)((float)div[nowIter] / (float)100));

            leftNode = new NodeBSP(new Chamber(room.getX(), room.getY(), room.getWidth(), newHeight));
            rightNode = new NodeBSP(new Chamber(room.getX(), room.getY() + newHeight, room.getWidth(), room.getHeight() - newHeight));
        }

        leftNode.root = root;
        rightNode.root = root;
        leftNode.father = this;
        rightNode.father = this;
        leftNode.side = 0;
        rightNode.side = 1;

        leftNode.split(numIter, nowIter+1,div);
        rightNode.split(numIter, nowIter+1,div);

    }

    public void resizeRooms(){
        if (leftNode == null && rightNode == null){
            int startx = RandNumberGen.GetRandomNumber(10, 21);
            int endx = RandNumberGen.GetRandomNumber(80, 91);
            int starty = RandNumberGen.GetRandomNumber(10, 21);
            int endy = RandNumberGen.GetRandomNumber(80, 91);
            room.setX((float)((int)(room.getX() + (room.getWidth() * (float)startx / (float)100))));
            room.setY((float)((int)(room.getY() + (room.getHeight() * (float)starty / (float)100))));
            room.setRoomDim((float)((int)(room.getWidth() * (float)(endx - startx) / (float)100)), 
                            (float)((int)(room.getHeight() * (float)(endy - starty) / (float)100)));
            if((int)room.getWidth() % 2 == 1){
                room.setRoomDim(room.getWidth() + 1, room.getHeight());
            }
            if((int)room.getHeight() % 2 == 1){ 
                room.setRoomDim(room.getWidth(), room.getHeight() + 1); 
            }
        }
        else{
            if (leftNode != null){
                leftNode.resizeRooms();
            }
            if (rightNode != null){
                rightNode.resizeRooms();
            }
        }
    }

    public void eliminateRooms(int numRooms) {

        int i;

        for(i = 0; i < numRooms; i++) {
            eliminateRoom();
        }

    }

    private void eliminateRoom() {

        if(leftNode == null && rightNode == null){
            if(side == 0) {
                father.leftNode = null;
            }else{
                father.rightNode = null;
            }
        }else if(leftNode == null && rightNode != null){
            rightNode.eliminateRoom();
        }else if(rightNode == null && leftNode != null){
            leftNode.eliminateRoom();
        }else{
            int pside = RandNumberGen.GetRandomNumber(0, 2);
            if(pside == 0){
                leftNode.eliminateRoom();
            }else{
                rightNode.eliminateRoom();
            }
        }

    }

    public void genCorridors(int nowIter){

        if(leftNode == null && rightNode == null){
            return;
        }else if(leftNode != null && rightNode != null){
            List<Chamber> leftRooms = leftNode.getRooms();
            List<Chamber> rightRooms = rightNode.getRooms();
            int leftSize = leftRooms.Count;
            int rightSize = rightRooms.Count;

            int dir = nowIter % 2;
            int minDist = 1000;
            int dist = 0;

            Chamber leftroom = leftRooms[0];
            Chamber rightroom = rightRooms[0];
            
            foreach(Chamber rooml in leftRooms){
                foreach(Chamber roomr in rightRooms){
                    dist = Math.Abs((int)(rooml.getX()-roomr.getX())) + Math.Abs((int)(rooml.getY()-roomr.getY()));

                    if (dist < minDist) {
                        minDist = dist;
                        rightroom = roomr;
                        leftroom = rooml;
                    }
                }
            }

            Chamber srcRoom;
            Chamber dstRoom;

            if(dir == 0){ // Split horizontally

                if(leftroom.getX() < rightroom.getX()){
                    srcRoom = leftroom;
                    dstRoom = rightroom;
                }else{
                    srcRoom = rightroom; 
                    dstRoom = leftroom;
                }

                if(srcRoom.getY() > dstRoom.getY()+dstRoom.getHeight() && srcRoom.getY() + srcRoom.getHeight() > dstRoom.getY() + dstRoom.getHeight()){

                    int corrStart = RandNumberGen.GetRandomNumber((int)(srcRoom.getX()), (int)(srcRoom.getX() + srcRoom.getWidth() - 5));
                    int corrEnd = RandNumberGen.GetRandomNumber((int)(dstRoom.getY()), (int)(dstRoom.getY() + dstRoom.getHeight() - 5));

                    Corridor newCorrV = new Corridor(corrStart, corrEnd, 5, srcRoom.getY() - corrEnd);
                    Corridor newCorrH = new Corridor(corrStart + 5, corrEnd, dstRoom.getX() - (corrStart + 5), 5);

                    srcRoom.addCorridor(newCorrV, 3);
                    dstRoom.addCorridor(newCorrH, 4);

                    newCorrH.setSrcRoom(srcRoom);
                    newCorrH.setDstRoom(dstRoom);
                    newCorrV.setSrcRoom(srcRoom);
                    newCorrV.setDstRoom(dstRoom);

                    root.corridors.Add(newCorrV);
                    root.corridors.Add(newCorrH);

                    for(int i = 1; i < (int)newCorrV.getWidth() - 1; i++) {
                        newCorrV.setPos(i, (int)newCorrV.getHeight() - 1, 2);
                        newCorrV.setPos((int)newCorrV.getWidth() - 1, i, 2);
                        newCorrH.setPos(0, i, 2);
                        newCorrH.setPos((int)newCorrH.getWidth() - 1, i, 2);
                        srcRoom.setPos(corrStart - (int)srcRoom.getX() + i, 0, 2);
                        dstRoom.setPos(0, corrEnd - (int)dstRoom.getY() + i, 2);
                    }

                }else if(dstRoom.getY() > srcRoom.getY() + srcRoom.getHeight() && dstRoom.getY() + dstRoom.getHeight() > srcRoom.getY() + srcRoom.getHeight()){

                    int corrStart = RandNumberGen.GetRandomNumber((int)(srcRoom.getY()), (int)(srcRoom.getY() + srcRoom.getHeight() - 5));
                    int corrEnd = RandNumberGen.GetRandomNumber((int)(dstRoom.getX()), (int)(dstRoom.getX() + dstRoom.getWidth() - 5));

                    Corridor newCorrH = new Corridor(srcRoom.getX() + srcRoom.getWidth(), corrStart, corrEnd - (srcRoom.getX() + srcRoom.getWidth()), 5);
                    Corridor newCorrV = new Corridor(corrEnd, corrStart, 5, dstRoom.getY() - corrStart);

                    srcRoom.addCorridor(newCorrH, 2);
                    dstRoom.addCorridor(newCorrV, 3);

                    newCorrH.setSrcRoom(srcRoom);
                    newCorrH.setDstRoom(dstRoom);
                    newCorrV.setSrcRoom(srcRoom);
                    newCorrV.setDstRoom(dstRoom);

                    root.corridors.Add(newCorrH);
                    root.corridors.Add(newCorrV);

                    for(int i = 1; i < (int)newCorrH.getHeight() - 1; i++) {
                        newCorrH.setPos(0, i, 2);
                        newCorrH.setPos((int)newCorrH.getWidth() - 1, i, 2);
                        newCorrV.setPos(0, i, 2);
                        newCorrV.setPos(i, (int)newCorrV.getHeight() - 1, 2);
                        srcRoom.setPos((int)srcRoom.getWidth() - 1, corrStart - (int)srcRoom.getY() + i, 2);
                        dstRoom.setPos(corrEnd - (int)dstRoom.getX() + i, 0, 2);
                    }

                }else{

                    List<int> ranges = new List<int>();

                    ranges.Add((int)srcRoom.getY());
                    ranges.Add((int)srcRoom.getY() + (int)srcRoom.getHeight());
                    ranges.Add((int)dstRoom.getY());
                    ranges.Add((int)dstRoom.getY() + (int)dstRoom.getHeight());

                    ranges.Sort();

                    int corrStart = 0;

                    if(ranges[1] < ranges[2] - 5) {
                        corrStart = RandNumberGen.GetRandomNumber(ranges[1], ranges[2] - 5);
                    }else{
                        corrStart = (int)ranges[1];
                    }

                    Corridor newCorr = new Corridor(srcRoom.getX() + srcRoom.getWidth(), corrStart, dstRoom.getX() - (srcRoom.getX() + srcRoom.getWidth()), 5);

                    for(int i = 1; i < (int)newCorr.getHeight() - 1; i++) {
                        newCorr.setPos(0, i, 2);
                        newCorr.setPos((int)newCorr.getWidth() - 1, i, 2);
                        srcRoom.setPos((int)srcRoom.getWidth() - 1, corrStart - (int)srcRoom.getY() + i, 2);
                        dstRoom.setPos(0, corrStart - (int)dstRoom.getY() + i, 2);
                    }

                    srcRoom.addCorridor(newCorr, 2);
                    dstRoom.addCorridor(newCorr, 4);

                    newCorr.setSrcRoom(srcRoom);
                    newCorr.setDstRoom(dstRoom);

                    root.corridors.Add(newCorr);
                
                }

            }else{ // Split vertically

                if(leftroom.getY() < rightroom.getY()){
                    srcRoom = leftroom;
                    dstRoom = rightroom;
                }else{
                    srcRoom = rightroom;
                    dstRoom = leftroom;
                }

                if(srcRoom.getX() > dstRoom.getX() + dstRoom.getWidth() && srcRoom.getX() + srcRoom.getWidth() > dstRoom.getX() + dstRoom.getWidth()){

                    int corrStart = RandNumberGen.GetRandomNumber((int)(dstRoom.getX()), (int)(dstRoom.getX() + dstRoom.getWidth() - 5));
                    int corrEnd = RandNumberGen.GetRandomNumber((int)(srcRoom.getY()), (int)(srcRoom.getY() + srcRoom.getHeight() - 5));

                    Corridor newCorrV = new Corridor(corrStart, corrEnd, 5, dstRoom.getY() - corrEnd);
                    Corridor newCorrH = new Corridor(corrStart + 5, corrEnd, srcRoom.getX() - (corrStart + 5), 5);

                    srcRoom.addCorridor(newCorrH, 4);
                    dstRoom.addCorridor(newCorrV, 3);

                    newCorrH.setSrcRoom(srcRoom);
                    newCorrH.setDstRoom(dstRoom);
                    newCorrV.setSrcRoom(srcRoom);
                    newCorrV.setDstRoom(dstRoom);

                    root.corridors.Add(newCorrV);
                    root.corridors.Add(newCorrH);

                    for (int i = 1; i < (int)newCorrV.getWidth() - 1; i++) {
                        newCorrV.setPos(i, (int)newCorrV.getHeight() - 1, 2);
                        newCorrV.setPos((int)newCorrV.getWidth() - 1, i, 2);
                        newCorrH.setPos(0, i, 2);
                        newCorrH.setPos((int)newCorrH.getWidth() - 1, i, 2);
                        dstRoom.setPos(corrStart - (int)dstRoom.getX() + i, 0, 2);
                        srcRoom.setPos(0, corrEnd - (int)srcRoom.getY() + i, 2);
                    }

                } else if(dstRoom.getX() > srcRoom.getX() + srcRoom.getWidth() && dstRoom.getX() + dstRoom.getWidth() > srcRoom.getX() + srcRoom.getWidth()) {

                    int corrStart = RandNumberGen.GetRandomNumber((int)(srcRoom.getY()), (int)(srcRoom.getY() + srcRoom.getHeight() - 5));
                    int corrEnd = RandNumberGen.GetRandomNumber((int)(dstRoom.getX()), (int)(dstRoom.getX() + dstRoom.getWidth() - 5));

                    Corridor newCorrH = new Corridor(srcRoom.getX() + srcRoom.getWidth(), corrStart, corrEnd - (srcRoom.getX() + srcRoom.getWidth()), 5);
                    Corridor newCorrV = new Corridor(corrEnd, corrStart, 5, dstRoom.getY() - corrStart);

                    srcRoom.addCorridor(newCorrH, 2);
                    dstRoom.addCorridor(newCorrV, 3);

                    newCorrH.setSrcRoom(srcRoom);
                    newCorrH.setDstRoom(dstRoom);
                    newCorrV.setSrcRoom(srcRoom);
                    newCorrV.setDstRoom(dstRoom);

                    root.corridors.Add(newCorrH);
                    root.corridors.Add(newCorrV);

                    for (int i = 1; i < (int)newCorrH.getHeight() - 1; i++) {
                        newCorrH.setPos(0, i, 2);
                        newCorrH.setPos((int)newCorrH.getWidth() - 1, i, 2);
                        newCorrV.setPos(0, i, 2);
                        newCorrV.setPos(i, (int)newCorrV.getHeight() - 1, 2);
                        srcRoom.setPos((int)srcRoom.getWidth() - 1, corrStart - (int)srcRoom.getY() + i, 2);
                        dstRoom.setPos(corrEnd - (int)dstRoom.getX() + i, 0, 2);
                    }

                } else{

                    List<float> ranges = new List<float>();

                    ranges.Add(srcRoom.getX());
                    ranges.Add(srcRoom.getX() + srcRoom.getWidth());
                    ranges.Add(dstRoom.getX());
                    ranges.Add(dstRoom.getX() + dstRoom.getWidth());

                    ranges.Sort();

                    int corrStart = 0;

                    if(ranges[1] < ranges[2] - 5) {
                        corrStart = RandNumberGen.GetRandomNumber((int)ranges[1], (int)ranges[2] - 5);
                    } else {
                        corrStart = (int)ranges[1];
                    }

                    Corridor newCorr = new Corridor(corrStart, srcRoom.getY() + srcRoom.getHeight(), 5, dstRoom.getY() - (srcRoom.getY() + srcRoom.getHeight()));

                    for (int i = 1; i < (int)newCorr.getWidth() - 1; i++) {
                        newCorr.setPos(i, 0, 2);
                        newCorr.setPos(i, (int)newCorr.getHeight() - 1, 2);
                        srcRoom.setPos(corrStart - (int)srcRoom.getX() + i, (int)srcRoom.getHeight() - 1, 2);
                        dstRoom.setPos(corrStart - (int)dstRoom.getX() + i, 0, 2);
                    }

                    srcRoom.addCorridor(newCorr, 1);
                    dstRoom.addCorridor(newCorr, 3);

                    newCorr.setSrcRoom(srcRoom);
                    newCorr.setDstRoom(dstRoom);

                    root.corridors.Add(newCorr);
                
                }

            }

        }

        if(leftNode != null){
            leftNode.genCorridors(nowIter + 1);
        }
        if(rightNode != null){
            rightNode.genCorridors(nowIter + 1);
        }

    }

    public void placeWalls<T>(List<T> rooms) where T : Room{
        
        foreach(Room room in rooms) {

            for(int i = 0; i < room.getWidth(); i++) {
                if(room.getPos(i, 0) != 2) {
                    room.setPos(i, 0, 0);
                }
                if (room.getPos(i, (int)room.getHeight() - 1) != 2) {
                    room.setPos(i, (int)room.getHeight() - 1, 0);
                }
            }

            for (int i = 0; i < room.getHeight(); i++) {
                if (room.getPos(0, i) != 2) {
                    room.setPos(0, i, 0);
                }
                if (room.getPos((int)room.getWidth() - 1, i) != 2) {
                    room.setPos((int)room.getWidth() - 1, i, 0);
                }
            }

        }

    }

    public List<Chamber> getRooms(){

        List<Chamber> rooms = new List<Chamber>();
        
        if(leftNode == null && rightNode == null){
            rooms.Add(room);
        }
        else{
            if(leftNode != null){
                rooms.AddRange(leftNode.getRooms());
            }
            if(rightNode != null){
                rooms.AddRange(rightNode.getRooms());
            }
        }

        return rooms;
    }

    public List<Corridor> getCorridors() {

        return root.corridors;

    }

}
