using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Bullet : MonoBehaviour{

    private Vector2 direction;
    private float baseSpeed = 5f;
    private Rigidbody2D rb;

    private void Start() {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate() {
        rb.velocity = direction * baseSpeed * Global.speedMult;
    }

    protected virtual void OnTriggerEnter2D(Collider2D other) {
        if (other.CompareTag("Wall")) {
            Destroy(gameObject);
        }
    }

    public void setDirection(Vector2 newDirection) {
        direction = newDirection;
    }

    public Vector2 getDirection() {
        return direction;
    }

    public void setBaseSpeed(float speed) {
        baseSpeed = speed;
    }

    public float getBaseSpeed() {
        return baseSpeed;
    }

}
