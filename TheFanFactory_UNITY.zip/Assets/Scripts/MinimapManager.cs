using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapManager : MonoBehaviour
{
    public Camera minimapCamera;
    public Camera bigMinimapCamera;
    public GameObject minimapUI;
    public GameObject bigMinimapUI;

    private void Start() {
        minimapCamera.enabled = true;
        bigMinimapCamera.enabled = false;
        minimapUI.SetActive(true);
        bigMinimapUI.SetActive(false);
    }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.Tab)) {
            minimapCamera.enabled = false;
            bigMinimapCamera.enabled = true;
            minimapUI.SetActive(false);
            bigMinimapUI.SetActive(true);
        } else if (Input.GetKeyUp(KeyCode.Tab)) {
            minimapCamera.enabled = true;
            bigMinimapCamera.enabled = false;
            minimapUI.SetActive(true);
            bigMinimapUI.SetActive(false);
        }
    }
}
