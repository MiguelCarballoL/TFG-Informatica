using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[Serializable]
public class SaveData {
    public float diffMult;

    public int killedEnemies;

    public int hitsTaken;

    public int shotsFired;

    public int shotsHit;

    public List<float> diffMultList;

    public List<int> killedEnemiesList;

    public List<int> hitsTakenList;

    public List<int> shotsFiredList;

    public List<int> shotsHitList;
    public SaveData() {
        diffMult = 1f;
        killedEnemies = 0;
        hitsTaken = 0;
        shotsFired = 0;
        shotsHit = 0;
        diffMultList = new List<float>();
        killedEnemiesList = new List<int>();
        hitsTakenList = new List<int>();
        shotsFiredList = new List<int>();
        shotsHitList = new List<int>();
    }

}