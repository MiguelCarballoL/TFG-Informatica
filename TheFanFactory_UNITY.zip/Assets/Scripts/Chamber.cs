using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chamber : Room
{

    private List<Enemy> enemies = new List<Enemy>();
    private List<(Corridor corridor, int value)> corridorList = new List<(Corridor, int)>();

    public Chamber(float _x, float _y, float _width, float _height)
     : base(_x, _y, _width, _height) {

    }

    public void addEnemy(Enemy enemy) {
        enemies.Add(enemy);
    }

    public bool isEnemies() {
        foreach(Enemy enemy in enemies) {
            if(enemy != null) {
                return true;
            }
        }
        return false;
    }

    public void addCorridor(Corridor corridor, int value) {
        corridorList.Add((corridor, value));
    }

    public List<(Corridor corridor, int value)> getCorridors() {
        return corridorList;
    }

}
