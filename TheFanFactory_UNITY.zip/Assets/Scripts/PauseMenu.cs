using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class PauseMenu : MonoBehaviour{

    public GameObject pauseMenuUI;
    public GameObject controlsMenuUI;
    public GameObject statsMenuUI;
    public GameOverMenu gameOverMenuUI;
    public VictoryMenu victoryMenuUI;
    public TextMeshProUGUI statsText;
    public ProceduralGen procGen;

    private bool isPaused = false;
    private bool inControlsMenu = false;
    private bool inStatsMenu = false;
    private bool isBoss = false;
    [SerializeField]
    public BossHealthManager bossHealth;

    private void Update() {
        if (Input.GetKeyDown(KeyCode.Escape) && gameOverMenuUI.getIsGameOver() == false && victoryMenuUI.getIsVictory() == false) {
            if (inControlsMenu || isPaused || inStatsMenu) {
                resume();
            } else {
                pause();
            }
        }
    }

    public void resume() {
        pauseMenuUI.SetActive(false);
        controlsMenuUI.SetActive(false);
        statsMenuUI.SetActive(false);
        if(isBoss == true) {
            bossHealth.gameObject.SetActive(true);
        }
        Time.timeScale = 1f;
        isPaused = false;
        inControlsMenu = false;
        inStatsMenu = false;
        procGen.musicVolume(0.5f);
    }

    public void pause() {
        procGen.musicVolume(0.15f);
        if(bossHealth.gameObject.activeSelf == true) {
            bossHealth.gameObject.SetActive(false);
            isBoss = true;
        }
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f;
        isPaused = true;
    }

    public void loadControlsMenu() {
        pauseMenuUI.SetActive(false);
        controlsMenuUI.SetActive(true);
        inControlsMenu = true;
    }

    public void unloadControlsMenu() {
        pauseMenuUI.SetActive(true);
        controlsMenuUI.SetActive(false);
        inControlsMenu = false;
    }

    public void loadStatsMenu() {
        procGen.displayStats(statsText);
        pauseMenuUI.SetActive(false);
        statsMenuUI.SetActive(true);
        inStatsMenu = true;
    }

    public void unloadStatsMenu() {
        pauseMenuUI.SetActive(true);
        statsMenuUI.SetActive(false);
        inStatsMenu = false;
    }

    public void loadMainMenu() {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenuScene");
    }

}

