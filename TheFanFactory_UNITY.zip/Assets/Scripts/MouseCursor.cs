using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseCursor : MonoBehaviour {

    [SerializeField]
    private Texture2D customCursor;
    private Vector2 hotspot = new Vector2(16, 16);
    private CursorMode cursorMode = CursorMode.Auto;

    private void Start() {
        Cursor.SetCursor(customCursor, hotspot, cursorMode);
    }

}
