using System.Collections;
using System.Collections.Generic;
using TMPro;
using TMPro.Examples;
using UnityEngine;

public class ProceduralGen : MonoBehaviour{

    [SerializeField]
    public int height = 160;
    [SerializeField]
    public int width = 160;
    [SerializeField]
    public int numIter = 4;
    [SerializeField]
    public int numDelete = 5;
    [SerializeField]
    public TilemapGenerator tilemapGenerator;
    [SerializeField]
    public GameObject player;
    [SerializeField]
    public GameObject enemyTurretPrefab;
    [SerializeField]
    public GameObject enemyTurretCirclePrefab;
    [SerializeField]
    public GameObject enemyChaserPrefab;
    [SerializeField]
    public GameObject enemyChaserSpeedPrefab;
    [SerializeField]
    public GameObject enemyShooterPrefab;
    [SerializeField]
    public GameObject enemyShooterThreePrefab;
    [SerializeField]
    public GameObject enemyShooterFivePrefab;
    [SerializeField]
    public GameObject enemyMarkerPrefab;

    private List<Chamber> rooms = new List<Chamber>();
    private List<Corridor> corridors = new List<Corridor>();
    private Chamber currentRoom = null;
    private Chamber start;
    private int[,] floorMap;

    private float spawntimer = 0f;
    private bool spawning = false;
    private List<Vector3> spawnPos = new List<Vector3>();
    private bool spawned = false;
    private bool fighting = false;

    [SerializeField]
    private VictoryMenu victoryController;
    private int completed = 0;

    private SaveData currentData;

    // Start is called before the first frame update
    private void Start(){
        procGen();
    }

    public void procGen(){

        fighting = false;
        spawned = false;
        spawning = false;
        spawnPos.Clear();

        Global.killedEnemies = 0;
        Global.hitsTaken = 0;
        Global.shotsHit = 0;
        Global.shotsFired = 0;
        Global.diffMult = 1f;

        //SaveManager.DeleteSave();

        currentData = SaveManager.LoadGame();

        Global.diffMult = currentData.diffMult;

        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        foreach (GameObject e in enemies) {
            Destroy(e);
        }

        GameObject[] markers = GameObject.FindGameObjectsWithTag("Marker");
        foreach (GameObject m in markers) {
            Destroy(m);
        }

        NodeBSP root = new NodeBSP(new Chamber(0, 0, width, height));
        root.split(numIter, 0, null);
        root.eliminateRooms(numDelete);
        root.resizeRooms();
        root.genCorridors(0);
        rooms = root.getRooms();
        foreach(Chamber room in rooms) {
            room.setType(1);
        }
        corridors = root.getCorridors();
        root.placeWalls(rooms);
        root.placeWalls(corridors);
        start = setStart(rooms);
        spawnPlayer(start);
        
        foreach(Chamber room in rooms) {
            if(room.getType() == 1){
                randomizeRoom(room);
            }
        }

        GameObject[] bullets = GameObject.FindGameObjectsWithTag("Bullet");
        foreach (GameObject b in bullets) {
            Destroy(b);
        }
        currentRoom = null;

        genMap();

        tilemapGenerator.eraseFrame();

        tilemapGenerator.DrawFrame(width, height);
        tilemapGenerator.DrawRooms(rooms, floorMap);
        tilemapGenerator.DrawRooms(corridors, floorMap);

        tilemapGenerator.DrawMinimapRooms(rooms);
        tilemapGenerator.DrawMinimapCorridors(corridors);

    }

    // Update is called once per frame
    private void Update(){

        Vector2 playerPos = player.transform.position;

        if(spawning == true) {
            if(spawntimer <= 0f) {
                spawnEnemies();
                spawning = false;
            }
            spawntimer -= Time.deltaTime;
        }

        completed = 0;

        foreach (Chamber room in rooms) {
            if (room.isEnemies() == false && room.getVisited() == true && spawned == true) {
                completed++;
            }
        }

        if (completed == rooms.Count) {
            saveDataFunc();
            victoryController.Victory();
        }

        if (fighting == true) {
            if(spawned == true){
                if(currentRoom.isEnemies() == false) {
                    fighting = false;
                    tilemapGenerator.DrawDoors(currentRoom.getCorridors(), false);
                    spawned = false;
                }
            }
        }

        foreach (Chamber room in rooms) {
            if (playerPos.x >= room.getX() && playerPos.x < room.getX() + room.getWidth() &&
            playerPos.y >= room.getY() && playerPos.y < room.getY() + room.getHeight()) {
                
                if(currentRoom == null) {
                    room.setVisited(true);
                    foreach (Corridor corridor in corridors) {
                        if (corridor.getVisited() == true) {
                            continue;
                        }
                        if (corridor.getSrcRoom() == room || corridor.getDstRoom() == room) {
                            tilemapGenerator.DrawMinimapCorridor(corridor);
                            corridor.setVisited(true);
                        }
                    }
                    currentRoom = room;
                    tilemapGenerator.DrawHighlightMinimapRoom(room);
                }
                if (currentRoom != room) {
                    tilemapGenerator.DrawMinimapRoom(currentRoom);
                    currentRoom = room;
                    if (room.getVisited() == false) {
                        if(room.getType() == 1){
                            spawnPos.Clear();
                            spawntimer = 4f;
                            spawning = true;
                            spawnEnemiesPos(room);
                        }
                    }
                    room.setVisited(true);
                    foreach (Corridor corridor in corridors) {
                        if (corridor.getVisited() == true) {
                            continue;
                        }
                        if (corridor.getSrcRoom() == room || corridor.getDstRoom() == room) {
                            corridor.setVisited(true);
                            tilemapGenerator.DrawMinimapCorridor(corridor);
                        }
                    }
                    tilemapGenerator.DrawHighlightMinimapRoom(room);
                }
                break;
            }
        }
    }

    public void saveDataFunc() {
        currentData.hitsTaken += Global.hitsTaken;
        currentData.shotsHit += Global.shotsHit;
        currentData.shotsFired += Global.shotsFired;
        currentData.killedEnemies += Global.killedEnemies;
        float hitKillRatio = 1f;
        if (Global.killedEnemies > 0) {
            hitKillRatio = (float)Global.hitsTaken / (float)Global.killedEnemies;
        }
        float killScore = 0f;
        float shotScore = 0f;
        if (hitKillRatio < 0.05f) {
            killScore = 0.08f;
        } else if (hitKillRatio < 0.1f) {
            killScore = 0.06f;
        } else if (hitKillRatio < 0.2f) {
            killScore = 0.04f;
        } else if (hitKillRatio < 0.3f) {
            killScore = 0.02f;
        } else if (hitKillRatio < 0.4f) {
            killScore = 0f;
        } else if (hitKillRatio < 0.5f) {
            killScore = -0.02f;
        } else if (hitKillRatio < 0.6f) {
            killScore = -0.04f;
        } else if (hitKillRatio < 0.8f) {
            killScore = -0.06f;
        } else {
            killScore = -0.08f;
        }
        if(Global.shotsFired > 0) {
            shotScore = (((float)Global.shotsHit / (float)Global.shotsFired) - 0.5f) * 0.04f;
        }
        currentData.diffMult = Global.diffMult + shotScore + killScore;
        if (currentData.diffMult < 0.5f) {
            currentData.diffMult = 0.5f;
        }
        if (currentData.diffMult > 2f) {
            currentData.diffMult = 2f;
        }
        currentData.diffMultList.Add(Global.diffMult);
        if(currentData.diffMultList.Count > 10){
            currentData.diffMultList.RemoveAt(0);
        }
        currentData.hitsTakenList.Add(Global.hitsTaken);
        if(currentData.hitsTakenList.Count > 10){ 
            currentData.hitsTakenList.RemoveAt(0);
        }
        currentData.shotsHitList.Add(Global.shotsHit);
        if(currentData.shotsHitList.Count > 10){
            currentData.shotsHitList.RemoveAt(0);
        }
        currentData.shotsFiredList.Add(Global.shotsFired);
        if(currentData.shotsFiredList.Count > 10) {
            currentData.shotsFiredList.RemoveAt(0);
        }
        currentData.killedEnemiesList.Add(Global.killedEnemies);
        if(currentData.killedEnemiesList.Count > 10) {
            currentData.killedEnemiesList.RemoveAt(0);
        }

        SaveManager.SaveGame(currentData);
    }

    public void displayStats(TextMeshProUGUI statsText) {

        statsText.text = $"Difficulty multiplier: {currentData.diffMult:F2}";
        foreach(float diff in currentData.diffMultList) {
            statsText.text += $" | {diff:F2}";
        }
        statsText.text += $"\n\nEnemies killed: {currentData.killedEnemies + Global.killedEnemies}";
        foreach(int ene in currentData.killedEnemiesList) {
            statsText.text += $" | {ene}";
        }
        statsText.text += $"\n\nHits taken: {currentData.hitsTaken + Global.hitsTaken}";
        foreach(int hit in currentData.hitsTakenList) {
            statsText.text += $" | {hit}";
        }
        statsText.text += $"\n\nBullets shot: {currentData.shotsFired + Global.shotsFired}";
        foreach(int fir in currentData.shotsFiredList) {
            statsText.text += $" | {fir}";
        }
        statsText.text += $"\n\nBullets hit: {currentData.shotsHit + Global.shotsHit}";
        foreach(int shot in currentData.shotsHitList) {
            statsText.text += $" | {shot}";
        }

    }

    private Chamber setStart(List<Chamber> rooms){

        int minArea = 90000;
        Chamber minRoom = rooms[0];

        foreach(Chamber room in rooms){
            int newArea = (int)room.getWidth() * (int)room.getHeight();
            if(newArea < minArea) {
                minArea = newArea;
                minRoom = room;
            }
        }

        minRoom.setType(0);

        return minRoom;

    }

    private void spawnPlayer(Chamber room) {
        player.transform.position = new Vector3(room.getX() + room.getWidth() / 2, room.getY() + room.getHeight() / 2, 0);
    }

    private void randomizeRoom(Chamber room) {

        int randNum = RandNumberGen.GetRandomNumber(1, 10);

        if(randNum == 2 || randNum == 3){
            int randRoom = RandNumberGen.GetRandomNumber(2, 7);
            int centerWidth = (int)room.getWidth() / 2 - 1;
            int centerHeight = (int)room.getHeight() / 2 - 1;
            for (int i = 0; i < 2*randRoom; i++){
                for(int j = 0; j < 2*randRoom; j++){
                    if(i == 0 || j == 0 || i == 2*randRoom - 1 || j == 2*randRoom - 1) {
                        room.setPos(centerWidth - (randRoom - 1) + i, centerHeight - (randRoom - 1) + j, 0);
                    }else{
                        room.setPos(centerWidth - (randRoom - 1) + i, centerHeight - (randRoom - 1) + j, -1);
                    }
                }
            }
        }else if(randNum == 4){
            int randRoom = RandNumberGen.GetRandomNumber(1, 3);
            if(randRoom == 1) {
                int colX1 = 5;
                int colY1 = 5;
                int colX2 = (int)room.getWidth() - 9;
                int colY2 = (int)room.getHeight() - 9;
                for (int i = 0; i < 4; i++) {
                    for (int j = 0; j < 4; j++) {
                        if (i == 0 || j == 0 || i == 3 || j == 3) {
                            room.setPos(colX1 + i, colY1 + j, 0);
                            room.setPos(colX1 + i, colY2 + j, 0);
                            room.setPos(colX2 + i, colY1 + j, 0);
                            room.setPos(colX2 + i, colY2 + j, 0);
                        } else {
                            room.setPos(colX1 + i, colY1 + j, -1);
                            room.setPos(colX1 + i, colY2 + j, -1);
                            room.setPos(colX2 + i, colY1 + j, -1);
                            room.setPos(colX2 + i, colY2 + j, -1);
                        }
                    }
                }
            } else {
                int colX1 = 5;
                int colY1 = 5;
                int colX2 = (int)room.getWidth() - 9;
                int colY2 = (int)room.getHeight() - 9;
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        room.setPos(colX1 + i, colY1 + j, 0);
                        room.setPos(colX1 + i, colY2 + j, 0);
                        room.setPos(colX2 + i, colY1 + j, 0);
                        room.setPos(colX2 + i, colY2 + j, 0);
                    }
                }
                int centerWidth = (int)room.getWidth() / 2 - 1;
                int centerHeight = (int)room.getHeight() / 2 - 1;
                for (int i = 0; i < 4; i++) {
                    for (int j = 0; j < 4; j++) {
                        if (i == 0 || j == 0 || i == 3 || j == 3) {
                            room.setPos(centerWidth - 1 + i, centerHeight - 1 + j, 0);
                        } else {
                            room.setPos(centerWidth - 1 + i, centerHeight - 1 + j, -1);
                        }
                    }
                }
            }
        } else if(randNum == 5){
            int colX1 = 3;
            int colY1 = 3;
            int colX2 = (int)room.getWidth() - 5;
            int colY2 = (int)room.getHeight() - 5;
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    room.setPos(colX1 + i, colY1 + j, 0);
                    room.setPos(colX1 + i, colY2 + j, 0);
                    room.setPos(colX2 + i, colY1 + j, 0);
                    room.setPos(colX2 + i, colY2 + j, 0);
                }
            }
            int centerWidth = (int)room.getWidth() / 2 - 1;
            int centerHeight = (int)room.getHeight() / 2 - 1;
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    if (i == 0 || j == 0 || i == 3 || j == 3) {
                        room.setPos(centerWidth - 1 + i, centerHeight - 1 + j, 0);
                    } else {
                        room.setPos(centerWidth - 1 + i, centerHeight - 1 + j, -1);
                    }
                }
            }
        }else if(randNum == 6){
            int randRoom = RandNumberGen.GetRandomNumber(1, 3);
            if(randRoom == 1) {
                int colX1 = 5;
                int colY1 = 5;
                int colX2 = (int)room.getWidth() - 6;
                int colY2 = 6;
                int colY3 = (int)room.getHeight() - 7;
                int colY4 = (int)room.getHeight() - 6;
                for (int i = colX1; i <= colX2; i++) {
                    for (int j = colY1; j <= colY2; j++) {
                        room.setPos(i, j, 0);
                    }
                    for (int j = colY3; j <= colY4; j++) {
                        room.setPos(i, j, 0);
                    }
                }
            } else {
                int colY1 = 5;
                int colX1 = 5;
                int colY2 = (int)room.getHeight() - 6;
                int colX2 = 6;
                int colX3 = (int)room.getWidth() - 7;
                int colX4 = (int)room.getWidth() - 6;
                for (int i = colX1; i <= colX2; i++) {
                    for (int j = colY1; j <= colY2; j++) {
                        room.setPos(i, j, 0);
                    }
                }
                for (int i = colX3; i <= colX4; i++) {
                    for (int j = colY1; j <= colY2; j++) {
                        room.setPos(i, j, 0);
                    }
                }
            }
            
        } else if(randNum == 7 || randNum == 8){
            int centerWidth = (int)room.getWidth() / 2 - 1;
            int centerHeight = (int)room.getHeight() / 2 - 1;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 4; j++) {
                    if (i == 0 || j == 0 || i == 7 || j == 3) {
                        room.setPos(centerWidth - 3 + i, centerHeight - 1 + j, 0);
                    } else {
                        room.setPos(centerWidth - 3 + i, centerHeight - 1 + j, -1);
                    }
                }
            }
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 8; j++) {
                    if (i == 0 || j == 0 || i == 3 || j == 7) {
                        room.setPos(centerWidth - 1 + i, centerHeight - 3 + j, 0);
                    } else {
                        room.setPos(centerWidth - 1 + i, centerHeight - 3 + j, -1);
                    }
                }
            }
            room.setPos(centerWidth, centerHeight -1 , -1);
            room.setPos(centerWidth - 1, centerHeight, -1);
            room.setPos(centerWidth - 1, centerHeight + 1, -1);
            room.setPos(centerWidth + 1, centerHeight - 1, -1);
            room.setPos(centerWidth + 2, centerHeight, -1);
            room.setPos(centerWidth, centerHeight + 2, -1);
            room.setPos(centerWidth + 2, centerHeight + 1, -1);
            room.setPos(centerWidth + 1, centerHeight + 2, -1);
        } else if(randNum == 9) {
            int randRoom = RandNumberGen.GetRandomNumber(1, 5);
            if(randRoom == 1) {
                for(int i = 5; i < (int)room.getWidth() - 5; i++) {
                    room.setPos(i, 5, 0);
                    room.setPos(i, 6, 0);
                }
                for(int j = 5; j < (int)room.getHeight() - 5; j++) {
                    room.setPos(5, j, 0);
                    room.setPos(6, j, 0);
                    room.setPos((int)room.getWidth() - 6, j, 0);
                    room.setPos((int)room.getWidth() - 7, j, 0);
                }
            }else if(randRoom == 2) {
                for (int i = 5; i < (int)room.getWidth() - 5; i++) {
                    room.setPos(i, (int)room.getHeight() - 6, 0);
                    room.setPos(i, (int)room.getHeight() - 7, 0);
                }
                for (int j = 5; j < (int)room.getHeight() - 5; j++) {
                    room.setPos(5, j, 0);
                    room.setPos(6, j, 0);
                    room.setPos((int)room.getWidth() - 6, j, 0);
                    room.setPos((int)room.getWidth() - 7, j, 0);
                }
            } else if(randRoom == 3) {
                for (int i = 5; i < (int)room.getWidth() - 5; i++) {
                    room.setPos(i, 5, 0);
                    room.setPos(i, 6, 0);
                    room.setPos(i, (int)room.getHeight() - 6, 0);
                    room.setPos(i, (int)room.getHeight() - 7, 0);
                }
                for (int j = 5; j < (int)room.getHeight() - 5; j++) {
                    room.setPos(5, j, 0);
                    room.setPos(6, j, 0);
                }
            } else if(randRoom == 4) {
                for (int i = 5; i < (int)room.getWidth() - 5; i++) {
                    room.setPos(i, 5, 0);
                    room.setPos(i, 6, 0);
                    room.setPos(i, (int)room.getHeight() - 6, 0);
                    room.setPos(i, (int)room.getHeight() - 7, 0);
                }
                for (int j = 5; j < (int)room.getHeight() - 5; j++) {
                    room.setPos((int)room.getWidth() - 6, j, 0);
                    room.setPos((int)room.getWidth() - 7, j, 0);
                }
            }
        }

    } 

    private void spawnEnemiesPos(Chamber room) {

        int spawn = (int)(room.getWidth()/10f)+(int)(room.getHeight()/10f);
        spawn = (int)((float)spawn * Global.diffMult);

        while (spawn > 0) {
            int randX = RandNumberGen.GetRandomNumber(2, (int)room.getWidth() - 3);
            int randY = RandNumberGen.GetRandomNumber(2, (int)room.getHeight() - 3);
            bool spawnableEnemy = true;
            for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 3; j++) {
                    if(room.getPos(randX - 1 + i, randY - 1 + j) == 0 || room.getPos(randX - 1 + i, randY - 1 + j) == -1) {
                        spawnableEnemy = false;
                    }
                }
            }
            if(spawnableEnemy == true) {
                Vector3 newPos = new Vector3(room.getX() + randX, room.getY() + randY, 0);
                spawnPos.Add(newPos);
                Instantiate(enemyMarkerPrefab, newPos, Quaternion.identity);
                spawn--;
            }
        }

        tilemapGenerator.DrawDoors(currentRoom.getCorridors(), true);
        fighting = true;

    }

    private void spawnEnemies() {
        GameObject[] markers = GameObject.FindGameObjectsWithTag("Marker");
        foreach (GameObject m in markers) {
            Destroy(m);
        }
        foreach (Vector3 pos in spawnPos) {
            int randEnemy = RandNumberGen.GetRandomNumber(1, 5);
            GameObject enemyGO = null;
            if (randEnemy == 1){
                int randType = RandNumberGen.GetRandomNumber(1, 3);
                if (randType == 1) {
                    enemyGO = Instantiate(enemyTurretPrefab, pos, Quaternion.identity);
                } else if (randType == 2) {
                    enemyGO = Instantiate(enemyTurretCirclePrefab, pos, Quaternion.identity);
                }
            } else if(randEnemy == 2){
                int randType = RandNumberGen.GetRandomNumber(1, 3);
                if(randType == 1) {
                    enemyGO = Instantiate(enemyChaserPrefab, pos, Quaternion.identity);
                } else if(randType == 2) {
                    enemyGO = Instantiate(enemyChaserSpeedPrefab, pos, Quaternion.identity);
                }
            } else if(randEnemy == 3 || randEnemy == 4) {
                int randType = RandNumberGen.GetRandomNumber(1, 4);
                if (randType == 1) {
                    enemyGO = Instantiate(enemyShooterPrefab, pos, Quaternion.identity);
                } else if (randType == 2) {
                    enemyGO = Instantiate(enemyShooterThreePrefab, pos, Quaternion.identity);
                } else if (randType == 3) {
                    enemyGO = Instantiate(enemyShooterFivePrefab, pos, Quaternion.identity);
                }
            }
            Enemy enemy = enemyGO.GetComponent<Enemy>();
            enemy.setWorldMap(floorMap);
            currentRoom.addEnemy(enemy);
        }

        spawned = true;

    }

    private void genMap() {

        floorMap = new int[width, height];

        for(int i = 0; i < width; i++) {
            for(int j = 0; j < height; j++) {
                floorMap[i,j] = -1;
            }
        }

        foreach(Chamber room in rooms) {
            for(int i = 0; i < room.getWidth(); i++) {
                for(int j = 0; j < room.getHeight(); j++) {
                    floorMap[Mathf.FloorToInt(room.getX()) + i, Mathf.FloorToInt(room.getY()) + j] = room.getPos(i, j);
                }
            }
        }

        foreach(Corridor corridor in corridors) {
            for (int i = 0; i < corridor.getWidth(); i++) {
                for (int j = 0; j < corridor.getHeight(); j++) {
                    floorMap[Mathf.FloorToInt(corridor.getX()) + i, Mathf.FloorToInt(corridor.getY()) + j] = corridor.getPos(i, j);
                }
            }
        }

    }

    public List<Chamber> getRooms() {
        return rooms;
    }

    public List<Corridor> getCorridors() {
        return corridors;
    }

    public int[,] getFloorMap() {
        return floorMap;
    }

}
