using System.Collections;
using System.Collections.Generic;
using TMPro.Examples;
using UnityEngine;

public class PlayerBullet : Bullet
{
    private float damage;
    private bool hasHit = false;
    protected override void OnTriggerEnter2D(Collider2D other) {
        // Comportamiento extra para balas del jugador
        if (hasHit) {
            return;
        }
        if (other.CompareTag("Enemy")) {
            Enemy enemy = other.GetComponentInParent<Enemy>();
            if (enemy != null) {
                Global.shotsHit++;
                hasHit = true;
                enemy.TakeDamage(damage);
            }
            Destroy(gameObject);
        }

        // Llamar a la l�gica base si quer�s que siga funcionando igual con paredes
        base.OnTriggerEnter2D(other);
    }

    public void setDamage(float newDamage) {
        damage = newDamage;
    }

    public float getDamage() {
        return damage;
    }

}
