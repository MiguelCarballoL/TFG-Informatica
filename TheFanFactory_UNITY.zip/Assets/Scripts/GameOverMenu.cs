using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverMenu : MonoBehaviour{

    public GameObject gameOverPanel;
    private bool isGameOver = false;
    [SerializeField]
    public BossHealthManager bossHealth;

    public AudioSource musicSource;

    // Update is called once per frame
    void Update(){
        if (Input.GetKeyDown(KeyCode.Escape)) {
            if (isGameOver) {
                loadMainMenu();
            }
        }
    }

    public void gameOver() {
        musicSource.Play();
        bossHealth.gameObject.SetActive(false);
        gameOverPanel.SetActive(true);
        Time.timeScale = 0f;
        isGameOver = true;
    }

    public void newGame() {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenuScene");
        SceneManager.LoadScene("Gamescene");
    }

    public void loadMainMenu() {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenuScene");
    }

    public bool getIsGameOver() {
        return isGameOver;
    }
}
