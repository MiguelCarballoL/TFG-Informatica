using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour{
    private float playerSpeed = 7f;
    private Rigidbody2D rb;
    private Vector2 movement;
    private int pixelsPerUnit = 16;

    private float rollDuration = 0.4f;
    private float rollCooldown = 0.2f;
    private bool isRolling = false;
    private bool invulnerability = false;
    private Vector2 rollDirection;

    private float flickerDuration = 1.4f;
    private float flickerSpeed = 0.1f;

    private SpriteRenderer spriteRenderer;

    [SerializeField] 
    private GameObject playerBulletPrefab;
    private float bulletSpeed = 15f;
    private float damage = 1f;
    private float fireCooldown = 0.35f;
    private float nextFireTime = 0f;
    [SerializeField]
    private Transform firePoint;

    private Animator animator;
    // Start is called before the first frame update
    private void Start(){
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    private void Update(){
        if (!isRolling) {
            movement.x = Input.GetAxisRaw("Horizontal");
            movement.y = Input.GetAxisRaw("Vertical");

            movement = movement.normalized;

            if (Mathf.Abs(movement.x) > Mathf.Abs(movement.y)) {
                animator.SetFloat("MoveX", movement.x);
                animator.SetFloat("MoveY", 0);
            } else {
                animator.SetFloat("MoveX", 0);
                animator.SetFloat("MoveY", movement.y);
            }
            animator.SetBool("IsMoving", movement != Vector2.zero);

            if (Input.GetMouseButton(0) && Time.time >= nextFireTime) {
                shootBullet();
                nextFireTime = Time.time + fireCooldown;
            }

            if (Input.GetMouseButtonDown(1) && movement != Vector2.zero) {
                StartCoroutine(DodgeRoll());
            }
        }
        
    }

    private void FixedUpdate(){

        if (!isRolling) {
            Vector2 targetPosition = rb.position + movement * playerSpeed * Global.speedMult * Time.fixedDeltaTime;
            if (Global.speedMult > 0.25f) {
                targetPosition = new Vector2(Mathf.Round(targetPosition.x * pixelsPerUnit) / pixelsPerUnit,
                                            Mathf.Round(targetPosition.y * pixelsPerUnit) / pixelsPerUnit);
            }
            rb.MovePosition(targetPosition);
        }
        
    }

    private IEnumerator DodgeRoll() {
        isRolling = true;
        animator.SetBool("IsRolling", true);
        invulnerability = true;
        rollDirection = movement;

        float timer = 0f;
        while (timer < rollDuration) {
            rb.velocity = rollDirection * playerSpeed * Global.speedMult;
            timer += Time.deltaTime;
            yield return null;
        }
        invulnerability = false;
        timer = 0f;
        while (timer < rollCooldown) {
            rb.velocity = rollDirection * playerSpeed * Global.speedMult;
            timer += Time.deltaTime;
            yield return null;
        }
        animator.SetBool("IsRolling", false);
        isRolling = false;
    }

    public void TakeDamage() {
        StartCoroutine(Flicker());
    }

    private IEnumerator Flicker() {
        float elapsed = 0f;

        while (elapsed < flickerDuration) {
            spriteRenderer.enabled = false;
            yield return new WaitForSeconds(flickerSpeed);
            spriteRenderer.enabled = true;
            yield return new WaitForSeconds(flickerSpeed);

            elapsed += flickerSpeed * 2f;
        }
    }

    private void shootBullet() {
        Vector3 mouseWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0; // muy importante si est�s en 2D

        Vector2 dir = (mouseWorld - firePoint.position).normalized;

        Vector2 firePosition = (Vector2)transform.position + dir * 0.5f;

        GameObject bulletGO = Instantiate(playerBulletPrefab, firePosition, Quaternion.identity);
        PlayerBullet bullet = bulletGO.GetComponent<PlayerBullet>();
        bullet.setDamage(damage);
        bullet.setDirection(dir);
        bullet.setBaseSpeed(bulletSpeed);
        bullet.GetComponent<Rigidbody2D>().velocity = dir * bulletSpeed * Global.speedMult;

        Global.shotsFired++;
    }

    public void setSpeed(float speed){
        playerSpeed = speed;
    }

    public float getSpeed(){
        return playerSpeed;
    }

    public void setDamage(float newDamage) {
        damage = newDamage;
    }

    public float getDamage() {
        return damage;
    }

    public void setFireCooldown(float newFireCooldown) {
        fireCooldown = newFireCooldown;
    }

    public float getFireCooldown() {
        return fireCooldown;
    }

    public bool getIsRolling() {
        return isRolling;
    }

    public bool getInvulnerability() {
        return invulnerability;
    }

}
