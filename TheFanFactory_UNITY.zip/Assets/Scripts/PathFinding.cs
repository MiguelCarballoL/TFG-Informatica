using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class PathFinding{

    public static List<Vector2Int> findPath(int[,] grid, Vector2Int start, Vector2Int goal) {
        List<NodeA> openNodes = new List<NodeA>();
        HashSet<Vector2Int> closedNodes = new HashSet<Vector2Int>();
        NodeA startNode = new NodeA(start);

        openNodes.Add(startNode);

        while (openNodes.Count > 0) {

            openNodes.Sort((a, b) => a.getFCost().CompareTo(b.getFCost()));
            NodeA currentNode = openNodes[0];
            openNodes.RemoveAt(0);
            closedNodes.Add(currentNode.getPosition());

            if (currentNode.getPosition() == goal) {
                return reconstructPath(currentNode);
            }

            foreach (Vector2Int dir in Directions) {

                Vector2Int neighborPos = currentNode.getPosition() + dir;
                if (isWalkable(grid, neighborPos) == false || closedNodes.Contains(neighborPos) == true){
                    continue;
                }

                NodeA neighborNode = new NodeA(neighborPos);
                neighborNode.setGCost(currentNode.getGCost() + 1);
                neighborNode.setHCost(heuristic(neighborPos, goal));
                neighborNode.setParent(currentNode);

                NodeA existingNode = openNodes.Find(n => n.getPosition() == neighborNode.getPosition());
                if (existingNode == null || neighborNode.getGCost() < existingNode.getGCost()) {
                    if (existingNode != null){
                        openNodes.Remove(existingNode);
                    }
                    openNodes.Add(neighborNode);
                }

            }

        }

        return null;
    }

    private static List<Vector2Int> reconstructPath(NodeA end) {
        List<Vector2Int> path = new List<Vector2Int>();
        NodeA current = end;
        while (current != null) {
            path.Add(current.getPosition());
            current = current.getParent();
        }
        path.Reverse();
        return path;
    }

    private static int heuristic(Vector2Int a, Vector2Int b) {
        return Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);
    }

    private static bool isWalkable(int[,] grid, Vector2Int pos) {
        return pos.x >= 0 && pos.x < grid.GetLength(0)
            && pos.y >= 0 && pos.y < grid.GetLength(1)
            && grid[pos.x, pos.y] > 0;
    }

    public static Vector2Int adjustVector(int [,] grid, Vector2Int pos) {
        if(grid[pos.x, pos.y] == 0) {
            if(grid[pos.x, pos.y + 1] != 0) return new Vector2Int(pos.x, pos.y + 1);
            if(grid[pos.x, pos.y - 1] != 0) return new Vector2Int(pos.x, pos.y - 1);
            if(grid[pos.x + 1, pos.y] != 0) return new Vector2Int(pos.x + 1, pos.y);
            if(grid[pos.x - 1, pos.y] != 0) return new Vector2Int(pos.x - 1, pos.y);
        }

        return pos;
    }

    private static readonly Vector2Int[] Directions = {
        Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right
    };

}
