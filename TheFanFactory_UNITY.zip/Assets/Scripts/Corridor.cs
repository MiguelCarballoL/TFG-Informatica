using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Corridor : Room{

    private Chamber srcRoom;
    private Chamber dstRoom;
    public Corridor(float _x, float _y, float _width, float _height)
     : base(_x, _y, _width, _height) {

    }

    public void setSrcRoom(Chamber newSrcRoom) {
        srcRoom = newSrcRoom;
    }

    public Chamber getSrcRoom() {
        return srcRoom;
    }

    public void setDstRoom(Chamber newDstRoom) {
        dstRoom = newDstRoom;
    }

    public Chamber getDstRoom() {
        return dstRoom;
    }
}
