using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Global
{

    public static float speedMult = 1f;

    public static float diffMult = 1f;

    public static int killedEnemies = 0;

    public static int hitsTaken = 0;

    public static int shotsFired = 0;

    public static int shotsHit = 0;

}
