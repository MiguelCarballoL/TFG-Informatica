using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandNumberGen{

    private static System.Random rand = new System.Random();

    public static int GetRandomNumber(int min, int max){
        //Debug.Log($"N�MERO RANDOM ENTRE {min} y {max}");
        return rand.Next(min, max);
    }

}
