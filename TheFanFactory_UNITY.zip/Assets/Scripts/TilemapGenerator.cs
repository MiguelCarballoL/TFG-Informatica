using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TilemapGenerator : MonoBehaviour{
    [SerializeField]
    public Tilemap groundTilemap_B;
    [SerializeField]
    public Tilemap groundTilemap_W;
    [SerializeField]
    public Tilemap groundTilemap_Y;
    [SerializeField]
    public Tilemap groundTilemap_O;
    [SerializeField]
    public Tilemap groundTilemap_R;
    [SerializeField]
    public Tilemap wallTilemap;
    [SerializeField]
    public Tilemap minimapTilemap_B;
    [SerializeField]
    public Tilemap minimapTilemap_W;
    [SerializeField]
    public Tilemap minimapTilemap_Y;
    [SerializeField]
    public Tilemap minimapTilemap_O;
    [SerializeField]
    public Tilemap minimapTilemap_R;
    [SerializeField]
    public TileBase floorTile_B1;
    [SerializeField]
    public TileBase floorTile_B2;
    [SerializeField]
    public TileBase floorTile_B3;
    [SerializeField]
    public TileBase floorTile_B4;
    [SerializeField]
    public TileBase floorTile_B5;
    [SerializeField]
    public TileBase floorTile_B6;
    [SerializeField]
    public TileBase floorTile_B7;
    [SerializeField]
    public TileBase floorTile_W1;
    [SerializeField]
    public TileBase floorTile_W2;
    [SerializeField]
    public TileBase floorTile_W3;
    [SerializeField]
    public TileBase floorTile_W4;
    [SerializeField]
    public TileBase floorTile_W5;
    [SerializeField]
    public TileBase floorTile_W6;
    [SerializeField]
    public TileBase floorTile_W7;
    [SerializeField]
    public TileBase floorTile_Y1;
    [SerializeField]
    public TileBase floorTile_Y2;
    [SerializeField]
    public TileBase floorTile_Y3;
    [SerializeField]
    public TileBase floorTile_Y4;
    [SerializeField]
    public TileBase floorTile_Y5;
    [SerializeField]
    public TileBase floorTile_Y6;
    [SerializeField]
    public TileBase floorTile_Y7;
    [SerializeField]
    public TileBase floorTile_O1;
    [SerializeField]
    public TileBase floorTile_O2;
    [SerializeField]
    public TileBase floorTile_O3;
    [SerializeField]
    public TileBase floorTile_O4;
    [SerializeField]
    public TileBase floorTile_O5;
    [SerializeField]
    public TileBase floorTile_O6;
    [SerializeField]
    public TileBase floorTile_O7;
    [SerializeField]
    public TileBase floorTile_R1;
    [SerializeField]
    public TileBase floorTile_R2;
    [SerializeField]
    public TileBase floorTile_R3;
    [SerializeField]
    public TileBase floorTile_R4;
    [SerializeField]
    public TileBase floorTile_R5;
    [SerializeField]
    public TileBase floorTile_R6;
    [SerializeField]
    public TileBase floorTile_R7;
    [SerializeField]
    public TileBase OOBTile;
    [SerializeField]
    public TileBase wallTile_U;
    [SerializeField]
    public TileBase wallTile_R;
    [SerializeField]
    public TileBase wallTile_L;
    [SerializeField]
    public TileBase wallTile_D;
    [SerializeField]
    public TileBase wallTile_LU_IN;
    [SerializeField]
    public TileBase wallTile_LU_OUT;
    [SerializeField]
    public TileBase wallTile_LD_IN;
    [SerializeField]
    public TileBase wallTile_LD_OUT;
    [SerializeField]
    public TileBase wallTile_RU_IN;
    [SerializeField]
    public TileBase wallTile_RU_OUT;
    [SerializeField]
    public TileBase wallTile_RD_IN;
    [SerializeField]
    public TileBase wallTile_RD_OUT;
    [SerializeField]
    public TileBase minimapTile_B;
    [SerializeField]
    public TileBase minimapTile_W;
    [SerializeField]
    public TileBase minimapTile_Y;
    [SerializeField]
    public TileBase minimapTile_O;
    [SerializeField]
    public TileBase minimapTile_R;
    [SerializeField]
    public TileBase minimapBorderTile;
    [SerializeField]
    public TileBase minimapHighlightTile_B;
    [SerializeField]
    public TileBase minimapHighlightTile_W;
    [SerializeField]
    public TileBase minimapHighlightTile_Y;
    [SerializeField]
    public TileBase minimapHighlightTile_O;
    [SerializeField]
    public TileBase minimapHighlightTile_R;
    [SerializeField]
    public TileBase minimapOOBTile_B;
    [SerializeField]
    public TileBase minimapOOBTile_W;
    [SerializeField]
    public TileBase minimapOOBTile_Y;
    [SerializeField]
    public TileBase minimapOOBTile_O;
    [SerializeField]
    public TileBase minimapOOBTile_R;
    [SerializeField]
    public TileBase doorTile_U;
    [SerializeField]
    public TileBase doorTile_D;
    [SerializeField]
    public TileBase doorTile_L;
    [SerializeField]
    public TileBase doorTile_R;

    public void eraseFrame(){

        groundTilemap_B.ClearAllTiles();
        groundTilemap_W.ClearAllTiles();
        groundTilemap_Y.ClearAllTiles();
        groundTilemap_O.ClearAllTiles();
        groundTilemap_R.ClearAllTiles();
        wallTilemap.ClearAllTiles();
        minimapTilemap_B.ClearAllTiles();
        minimapTilemap_W.ClearAllTiles();
        minimapTilemap_Y.ClearAllTiles();
        minimapTilemap_O.ClearAllTiles();
        minimapTilemap_R.ClearAllTiles();

    }

    public void DrawFrame(int width, int height){

        for (int i = -100; i < width+100; i++) {
            for (int j = -100; j < height+100; j++) {
                groundTilemap_B.SetTile(new Vector3Int(i, j, 0), OOBTile);
                groundTilemap_W.SetTile(new Vector3Int(i, j, 0), OOBTile);
                groundTilemap_Y.SetTile(new Vector3Int(i, j, 0), OOBTile);
                groundTilemap_O.SetTile(new Vector3Int(i, j, 0), OOBTile);
                groundTilemap_R.SetTile(new Vector3Int(i, j, 0), OOBTile);
            }
        }

    }
    public void DrawRooms<T>(List<T> rooms, int[,] floorMap) where T : Room{

        foreach(Room room in rooms){
            DrawRoom(room, floorMap);
        }

    }

    private void DrawRoom<T>(T room, int[,] floorMap) where T : Room{

        for(int i = 0; i < room.getWidth(); i++){
            for(int j = 0; j < room.getHeight(); j++){
                if(room.getPos(i, j) == -1){
                    groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), OOBTile);
                    groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), OOBTile);
                    groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), OOBTile);
                    groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), OOBTile);
                    groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), OOBTile);
                } else if(room.getPos(i, j) == 0) {
                    if((floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == -1) ||
                       (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 &&
                        floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_L);
                    } else if ((floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == -1 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] > 0) ||
                               (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] > 0 &&
                                floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_R);
                    } else if ((floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == -1) ||
                               (floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                                floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_D);
                    } else if ((floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == -1 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] > 0) ||
                               (floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] > 0 &&
                                floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_U);
                    } else if ((floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 && 
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == -1 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == -1) ||
                               (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY() + 1] > 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_LD_OUT);
                    } else if (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] > 0) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_LD_IN);
                    } else if ((floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 && 
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == -1 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == -1) ||
                               (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY() - 1] > 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_LU_OUT);
                    } else if (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] > 0) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_LU_IN);
                    } else if ((floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 && 
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == -1 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == -1) ||
                               (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY() + 1] > 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_RD_OUT);
                    } else if (floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] > 0) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_RD_IN);
                    } else if ((floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 && 
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == -1 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == -1) ||
                               (floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() - 1, j + (int)room.getY() - 1] > 0)) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_RU_OUT);
                    } else if (floorMap[i + (int)room.getX() - 1, j + (int)room.getY()] == 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() - 1] == 0 &&
                               floorMap[i + (int)room.getX() + 1, j + (int)room.getY()] > 0 && floorMap[i + (int)room.getX(), j + (int)room.getY() + 1] > 0) {
                        wallTilemap.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), wallTile_RU_IN);
                    }
                } else{
                    int floorType = RandNumberGen.GetRandomNumber(1, 101);
                    if(floorType == 1) {
                        int tileType = RandNumberGen.GetRandomNumber(1, 4);
                        if(tileType == 1) {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B5);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W5);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y5);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O5);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R5);
                        } else if(tileType == 2) {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B6);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W6);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y6);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O6);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R6);
                        } else {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B7);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W7);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y7);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O7);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R7);
                        }
                    } else {
                        int tileType = RandNumberGen.GetRandomNumber(1, 9);
                        if (tileType == 1) {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B1);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W1);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y1);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O1);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R1);
                        } else if (tileType <= 4) {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B2);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W2);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y2);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O2);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R2);
                        } else if (tileType <= 6) {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B3);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W3);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y3);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O3);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R3);
                        } else {
                            groundTilemap_B.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_B4);
                            groundTilemap_W.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_W4);
                            groundTilemap_Y.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_Y4);
                            groundTilemap_O.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_O4);
                            groundTilemap_R.SetTile(new Vector3Int(i + (int)room.getX(), j + (int)room.getY(), 0), floorTile_R4);
                        }
                    }
                    
                }
            }
        }

    }

    public void setFloorTileMap(){
        if (TemperatureManager.Instance.getTemperature() <= 0) {
            groundTilemap_B.gameObject.SetActive(true);
            groundTilemap_W.gameObject.SetActive(false);
            groundTilemap_Y.gameObject.SetActive(false);
            groundTilemap_O.gameObject.SetActive(false);
            groundTilemap_R.gameObject.SetActive(false);
            minimapTilemap_B.gameObject.SetActive(true);
            minimapTilemap_W.gameObject.SetActive(false);
            minimapTilemap_Y.gameObject.SetActive(false);
            minimapTilemap_O.gameObject.SetActive(false);
            minimapTilemap_R.gameObject.SetActive(false);
        } else if (TemperatureManager.Instance.getTemperature() <= 20) {
            groundTilemap_B.gameObject.SetActive(false);
            groundTilemap_W.gameObject.SetActive(true);
            groundTilemap_Y.gameObject.SetActive(false);
            groundTilemap_O.gameObject.SetActive(false);
            groundTilemap_R.gameObject.SetActive(false);
            minimapTilemap_B.gameObject.SetActive(false);
            minimapTilemap_W.gameObject.SetActive(true);
            minimapTilemap_Y.gameObject.SetActive(false);
            minimapTilemap_O.gameObject.SetActive(false);
            minimapTilemap_R.gameObject.SetActive(false);
        } else if (TemperatureManager.Instance.getTemperature() <= 40) {
            groundTilemap_B.gameObject.SetActive(false);
            groundTilemap_W.gameObject.SetActive(false);
            groundTilemap_Y.gameObject.SetActive(true);
            groundTilemap_O.gameObject.SetActive(false);
            groundTilemap_R.gameObject.SetActive(false);
            minimapTilemap_B.gameObject.SetActive(false);
            minimapTilemap_W.gameObject.SetActive(false);
            minimapTilemap_Y.gameObject.SetActive(true);
            minimapTilemap_O.gameObject.SetActive(false);
            minimapTilemap_R.gameObject.SetActive(false);
        } else if (TemperatureManager.Instance.getTemperature() <= 70) {
            groundTilemap_B.gameObject.SetActive(false);
            groundTilemap_W.gameObject.SetActive(false);
            groundTilemap_Y.gameObject.SetActive(false);
            groundTilemap_O.gameObject.SetActive(true);
            groundTilemap_R.gameObject.SetActive(false);
            minimapTilemap_B.gameObject.SetActive(false);
            minimapTilemap_W.gameObject.SetActive(false);
            minimapTilemap_Y.gameObject.SetActive(false);
            minimapTilemap_O.gameObject.SetActive(true);
            minimapTilemap_R.gameObject.SetActive(false);
        } else {
            groundTilemap_B.gameObject.SetActive(false);
            groundTilemap_W.gameObject.SetActive(false);
            groundTilemap_Y.gameObject.SetActive(false);
            groundTilemap_O.gameObject.SetActive(false);
            groundTilemap_R.gameObject.SetActive(true);
            minimapTilemap_B.gameObject.SetActive(false);
            minimapTilemap_W.gameObject.SetActive(false);
            minimapTilemap_Y.gameObject.SetActive(false);
            minimapTilemap_O.gameObject.SetActive(false);
            minimapTilemap_R.gameObject.SetActive(true);
        }
    }

    public void DrawDoors(List<(Corridor corridor, int value)> corridorList, bool boolVal) {

        foreach (var item in corridorList) {
            if (item.value == 1) {
                if (boolVal == true) {
                    for(int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + 1, 0), doorTile_D);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + 1, 0), null);
                    }
                }
            } else if (item.value == 2) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + 1, (int)item.corridor.getY() + i, 0), doorTile_L);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + 1, (int)item.corridor.getY() + i, 0), null);
                    }
                }
            } else if (item.value == 3) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + (int)item.corridor.getHeight() - 2, 0), doorTile_U);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + (int)item.corridor.getHeight() - 2, 0), null);
                    }
                }
            } else if (item.value == 4) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + (int)item.corridor.getWidth() - 2, (int)item.corridor.getY() + i, 0), doorTile_R);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + (int)item.corridor.getWidth() - 2, (int)item.corridor.getY() + i, 0), null);
                    }
                }
            }
        }

    }

    public void DrawBossDoors(List<(Corridor corridor, int value)> corridorList, bool boolVal) {

        foreach (var item in corridorList) {
            if (item.value == 1) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + 1, 0), doorTile_U);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + 1, 0), null);
                    }
                }
            } else if (item.value == 2) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + 1, (int)item.corridor.getY() + i, 0), doorTile_R);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + 1, (int)item.corridor.getY() + i, 0), null);
                    }
                }
            } else if (item.value == 3) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + (int)item.corridor.getHeight() - 2, 0), doorTile_D);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + i, (int)item.corridor.getY() + (int)item.corridor.getHeight() - 2, 0), null);
                    }
                }
            } else if (item.value == 4) {
                if (boolVal == true) {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + (int)item.corridor.getWidth() - 2, (int)item.corridor.getY() + i, 0), doorTile_L);
                    }
                } else {
                    for (int i = 1; i <= 3; i++) {
                        wallTilemap.SetTile(new Vector3Int((int)item.corridor.getX() + (int)item.corridor.getWidth() - 2, (int)item.corridor.getY() + i, 0), null);
                    }
                }
            }
        }

    }

    public void DrawMinimapRooms(List<Chamber> chambers) {

        foreach (Chamber chamber in chambers) {
            if (chamber.getVisited() == true) {
                DrawMinimapRoom(chamber);
            }
        }

    }

    public void DrawMinimapRoom(Chamber chamber) {

        for (int i = 0; i < chamber.getWidth(); i++) {
            for (int j = 0; j < chamber.getHeight(); j++) {
                if (chamber.getPos(i, j) == -1){
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_B);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_W);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_Y);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_O);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_R);
                } else if(chamber.getPos(i, j) == 0){
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                } else {
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapTile_B);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapTile_W);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapTile_Y);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapTile_O);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapTile_R);
                }
            }
        }

    }

    public void DrawMinimapCorridors(List<Corridor> corridors) {

        foreach (Corridor corridor in corridors) {
            if(corridor.getVisited() == true){
                DrawMinimapCorridor(corridor);
            }
        }

    }

    public void DrawMinimapCorridor(Corridor corridor) {

        for (int i = 0; i < corridor.getWidth(); i++) {
            for (int j = 0; j < corridor.getHeight(); j++) {
                minimapTilemap_B.SetTile(new Vector3Int(i + (int)corridor.getX(), j + (int)corridor.getY(), 0), minimapTile_B);
                minimapTilemap_W.SetTile(new Vector3Int(i + (int)corridor.getX(), j + (int)corridor.getY(), 0), minimapTile_W);
                minimapTilemap_Y.SetTile(new Vector3Int(i + (int)corridor.getX(), j + (int)corridor.getY(), 0), minimapTile_Y);
                minimapTilemap_O.SetTile(new Vector3Int(i + (int)corridor.getX(), j + (int)corridor.getY(), 0), minimapTile_O);
                minimapTilemap_R.SetTile(new Vector3Int(i + (int)corridor.getX(), j + (int)corridor.getY(), 0), minimapTile_R);
            }
        }

    }

    public void DrawHighlightMinimapRoom(Chamber chamber) {

        for (int i = 0; i < chamber.getWidth(); i++) {
            for (int j = 0; j < chamber.getHeight(); j++) {
                if (chamber.getPos(i, j) == -1) {
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_B);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_W);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_Y);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_O);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapOOBTile_R);
                } else if (chamber.getPos(i, j) == 0) {
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapBorderTile);
                } else {
                    minimapTilemap_B.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapHighlightTile_B);
                    minimapTilemap_W.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapHighlightTile_W);
                    minimapTilemap_Y.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapHighlightTile_Y);
                    minimapTilemap_O.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapHighlightTile_O);
                    minimapTilemap_R.SetTile(new Vector3Int(i + (int)chamber.getX(), j + (int)chamber.getY(), 0), minimapHighlightTile_R);
                }
            }
        }

    }

}
