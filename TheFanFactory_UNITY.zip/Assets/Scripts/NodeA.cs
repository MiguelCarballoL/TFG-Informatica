using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodeA{

    private Vector2Int position;
    private int gCost;
    private int hCost;
    private int fCost => gCost + hCost;
    private NodeA parent;

    public NodeA(Vector2Int pos) {
        position = pos;
    }

    public void setPosition(Vector2Int newPosition) {
        position = newPosition;
    }

    public Vector2Int getPosition() {
        return position;
    }

    public void setGCost(int newGCost) { 
        gCost = newGCost;
    }

    public int getGCost() {
        return gCost;
    }

    public void setHCost(int newHCost) {
        hCost = newHCost;
    }

    public int getHCost() {
        return hCost;
    }

    public int getFCost() {
        return fCost;
    }

    public void setParent(NodeA newParent) {
        parent = newParent;
    }

    public NodeA getParent(){
        return parent;
    }

}
