using System.Collections;
using System.Collections.Generic;
using TMPro.Examples;
using UnityEngine;

public class TheFan : Enemy
{
    private float bulletCircleSpeed = 5f * Global.diffMult;
    private float bulletStraightSpeed = 10f * Global.diffMult;
    private float bulletGroupSpeed = 15f * Global.diffMult;
    private float fireCountdown = 4f;
    private float fireRate = 0.5f / Global.diffMult;
    private int lastAttack = 0;
    private bool isAttacking = false;
    [SerializeField]
    private GameObject enemyBulletPrefab;
    [SerializeField]
    private Transform firePoint;
    private Vector2 direction = new Vector2(0, 0);
    private Animator animator;
    private BossHealthManager bossHealth = null;

    [SerializeField]
    private AudioSource theFanWindSoundSource;
    [SerializeField]
    private AudioClip theFanCircleShotSoundClip;
    [SerializeField]
    private AudioClip theFanMultShotSoundClip;
    [SerializeField]
    private AudioClip theFanScatterShotSoundClip;
    [SerializeField]
    private AudioSource theFanShotSoundSource;

    protected override void Start() {
        maxHealth = 100;
        animator = GetComponent<Animator>();
        base.Start();
        bossHealth = FindObjectOfType<BossHealthManager>();
        bossHealth.SetHealth(currentHealth, maxHealth);
    }

    public override void TakeDamage(float amount) {
        base.TakeDamage(amount);
        bossHealth.SetHealth(currentHealth, maxHealth);
    }

    private void Update() {

        if (player == null) return;

        AimAtPlayer();
            
        if (fireCountdown <= 0f && isAttacking == false) {
            int randAttack = RandNumberGen.GetRandomNumber(1, 5);
            if(randAttack == 1) {
                if(lastAttack != 1) {
                    isAttacking = true;
                    animator.SetBool("isMoving", true);
                    theFanWindSoundSource.Play();
                    StartCoroutine(Attack1());
                    theFanWindSoundSource.Stop();
                    lastAttack = 1;
                }
            } else if(randAttack == 2) {
                if (lastAttack != 2) {
                    isAttacking = true;
                    animator.SetBool("isMoving", true);
                    theFanWindSoundSource.Play();
                    StartCoroutine(Attack2());
                    theFanWindSoundSource.Stop();
                    lastAttack = 2;
                }
            } else if(randAttack == 3) {
                if (lastAttack != 3) {
                    isAttacking = true;
                    animator.SetBool("isMoving", true);
                    theFanWindSoundSource.Play();
                    StartCoroutine(Attack3());
                    theFanWindSoundSource.Stop();
                    lastAttack = 3;
                }
            } else if(randAttack == 4) {
                if (lastAttack != 4) {
                    isAttacking = true;
                    animator.SetBool("isMoving", true);
                    theFanWindSoundSource.Play();
                    StartCoroutine(Attack4());
                    theFanWindSoundSource.Stop();
                    lastAttack = 4;
                }
            }

        }

        fireCountdown -= Time.deltaTime;

    }

    private void AimAtPlayer() {
        direction = (player.position - transform.position).normalized;
    }

    private IEnumerator Attack1() {

        for(int l = 0; l < 5; l++){
            for (int j = 0; j < 2; j++) {
                theFanShotSoundSource.PlayOneShot(theFanCircleShotSoundClip);
                yield return new WaitForSeconds(0.2f);
                for (int i = 0; i < 72; i++){
                    GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
                    float angleOffset = 5f * j + 5f * i;
                    Vector2 noisyDirection = Quaternion.Euler(0, 0, angleOffset) * direction;
                    bullet.GetComponent<Bullet>().setDirection(noisyDirection);
                    bullet.GetComponent<Bullet>().setBaseSpeed(bulletCircleSpeed);
                }
            }
            yield return new WaitForSeconds(1f);
        }

        animator.SetBool("isMoving", false);
        fireCountdown = 1f / fireRate;
        isAttacking = false;

    }

    private IEnumerator Attack2() {
        for (int k = 0; k < 10; k++) {
            for (int j = 0; j < 2; j++) {
                theFanShotSoundSource.PlayOneShot(theFanCircleShotSoundClip);
                yield return new WaitForSeconds(0.5f);
                for (int i = 0; i < 36; i++) {
                    GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
                    float angleOffset = 5f * j + 10f * i;
                    Vector2 noisyDirection = Quaternion.Euler(0, 0, angleOffset) * direction;
                    bullet.GetComponent<Bullet>().setDirection(noisyDirection);
                    bullet.GetComponent<Bullet>().setBaseSpeed(bulletCircleSpeed);
                }
            }
        }

        animator.SetBool("isMoving", false);
        fireCountdown = 1f / fireRate;
        isAttacking = false;
    }

    private IEnumerator Attack3() {
        Vector2 perpDirection = new Vector2(-direction.y, direction.x).normalized;
        Vector3 spawnPosition = firePoint.position;
        for (int i = 0; i < 5; i++) {
            theFanShotSoundSource.PlayOneShot(theFanScatterShotSoundClip);
            GameObject bullet = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet.GetComponent<Bullet>().setDirection(direction);
            bullet.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * 0.5f + direction.x * 0.25f, perpDirection.y * 0.5f + direction.y * 0.25f, 0f);
            GameObject bullet2 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet2.GetComponent<Bullet>().setDirection(direction);
            bullet2.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * -0.5f + direction.x * 0.25f, perpDirection.y * -0.5f + direction.y * 0.25f, 0f);
            GameObject bullet3 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet3.GetComponent<Bullet>().setDirection(direction);
            bullet3.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x + direction.x * 0.5f, perpDirection.y + direction.x * 0.5f, 0f);
            GameObject bullet4 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet4.GetComponent<Bullet>().setDirection(direction);
            bullet4.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * -1f + direction.x * 0.5f, perpDirection.y * -1f + direction.x * 0.5f, 0f);
            GameObject bullet5 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet5.GetComponent<Bullet>().setDirection(direction);
            bullet5.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * 0.5f + direction.x * 0.25f, perpDirection.y * 0.5f - direction.y * 0.25f, 0f);
            GameObject bullet6 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet6.GetComponent<Bullet>().setDirection(direction);
            bullet6.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * -0.5f + direction.x * 0.25f, perpDirection.y * -0.5f - direction.y * 0.25f, 0f);
            GameObject bullet7 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet7.GetComponent<Bullet>().setDirection(direction);
            bullet7.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x + direction.x * 0.5f, perpDirection.y - direction.x * 0.5f, 0f);
            GameObject bullet8 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet8.GetComponent<Bullet>().setDirection(direction);
            bullet8.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position + new Vector3(perpDirection.x * -1f + direction.x * 0.5f, perpDirection.y * -1f - direction.x * 0.5f, 0f);
            GameObject bullet9 = Instantiate(enemyBulletPrefab, spawnPosition, Quaternion.identity);
            bullet9.GetComponent<Bullet>().setDirection(direction);
            bullet9.GetComponent<Bullet>().setBaseSpeed(bulletGroupSpeed);
            spawnPosition = firePoint.position;
            yield return new WaitForSeconds(1f);
        }

        animator.SetBool("isMoving", false);
        fireCountdown = 1f / fireRate;
        isAttacking = false;
    }

    private IEnumerator Attack4() {
        theFanShotSoundSource.PlayOneShot(theFanMultShotSoundClip);
        for (int i = 0; i < 100; i++) {
            GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
            float angleOffset = Random.Range(-30f, 30f);
            Vector2 noisyDirection = Quaternion.Euler(0, 0, angleOffset) * direction;
            bullet.GetComponent<Bullet>().setDirection(noisyDirection);
            bullet.GetComponent<Bullet>().setBaseSpeed(bulletStraightSpeed);
            yield return new WaitForSeconds(0.05f);
        }

        animator.SetBool("isMoving", false);
        fireCountdown = 1f / fireRate;
        isAttacking = false;
    }

}
