using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooterThree : EnemyShooter
{
    // Start is called before the first frame update
    protected override void Start()
    {
        maxHealth = 4;
        speed = 1f;
        range = 14f;
        fireRate = 2f / Global.diffMult;
        bulletSpeed = 7.5f * Global.diffMult;
        base.Start();
    }
    protected override void Shoot() {
        GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        bullet.GetComponent<Bullet>().setDirection(direction);
        bullet.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet2 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection2 = Quaternion.Euler(0, 0, 5f) * direction;
        bullet2.GetComponent<Bullet>().setDirection(noisyDirection2);
        bullet2.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet3 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection3 = Quaternion.Euler(0, 0, -5f) * direction;
        bullet3.GetComponent<Bullet>().setDirection(noisyDirection3);
        bullet3.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        //bullet.GetComponent<Rigidbody2D>().velocity = noisyDirection * bulletSpeed * Global.speedMult;
    }
}
