using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooterFive : EnemyShooter
{
    // Start is called before the first frame update
    protected override void Start()
    {
        maxHealth = 6;
        speed = 1f;
        range = 13f;
        fireRate = 2.5f / Global.diffMult;
        bulletSpeed = 5f * Global.diffMult;
        base.Start();
    }

    protected override void Shoot() {
        GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        bullet.GetComponent<Bullet>().setDirection(direction);
        bullet.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet2 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection2 = Quaternion.Euler(0, 0, 5f) * direction;
        bullet2.GetComponent<Bullet>().setDirection(noisyDirection2);
        bullet2.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet3 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection3 = Quaternion.Euler(0, 0, -5f) * direction;
        bullet3.GetComponent<Bullet>().setDirection(noisyDirection3);
        bullet3.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet4 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection4 = Quaternion.Euler(0, 0, 10f) * direction;
        bullet4.GetComponent<Bullet>().setDirection(noisyDirection4);
        bullet4.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        GameObject bullet5 = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        Vector2 noisyDirection5 = Quaternion.Euler(0, 0, -10f) * direction;
        bullet5.GetComponent<Bullet>().setDirection(noisyDirection5);
        bullet5.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        //bullet.GetComponent<Rigidbody2D>().velocity = noisyDirection * bulletSpeed * Global.speedMult;
    }
}
