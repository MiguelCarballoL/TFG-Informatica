using System.Collections;
using System.Collections.Generic;
using TMPro.Examples;
using UnityEngine;

public abstract class Enemy : MonoBehaviour{
    
    protected float maxHealth = 0;
    protected float currentHealth;
    protected int[,] worldMap;
    protected Transform player;

    // Start is called before the first frame update
    protected virtual void Start(){
        currentHealth = maxHealth * Global.diffMult;
        player = GameObject.FindGameObjectWithTag("PlayerHitbox").transform;
    }

    // Update is called once per frame
    private void Update(){
        
    }

    public virtual void TakeDamage(float amount) {
        currentHealth -= amount;
        if (currentHealth <= 0f) {
            TemperatureManager.Instance.ChangeTemperature(2);
            Global.killedEnemies++;
            Destroy(gameObject);
        }
    }

    public void setWorldMap(int[,] newMap){
        worldMap = newMap;
    }

    public int[,] getWorldMap(){
        return worldMap;
    }

}
