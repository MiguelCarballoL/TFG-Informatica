using System.Collections;
using System.Collections.Generic;
using TMPro.Examples;
using UnityEngine;

public abstract class Enemy : MonoBehaviour{
    
    protected float maxHealth = 0;
    protected float currentHealth;
    protected int[,] worldMap;
    protected Transform player;

    private AudioSource enemyImpactSource;

    // Start is called before the first frame update
    protected virtual void Start(){
        maxHealth = maxHealth * Global.diffMult;
        currentHealth = maxHealth;
        player = GameObject.FindGameObjectWithTag("PlayerHitbox").transform;
        GameObject audioGO = GameObject.FindGameObjectWithTag("EnemyImpact");
        enemyImpactSource = audioGO.GetComponent<AudioSource>();
        enemyImpactSource.volume = 0.5f;
    }

    // Update is called once per frame
    private void Update(){
        
    }

    public virtual void TakeDamage(float amount) {
        currentHealth -= amount;
        enemyImpactSource.Play();
        if (currentHealth <= 0f) {
            TemperatureManager.Instance.ChangeTemperature(2);
            Global.killedEnemies++;
            Destroy(gameObject);
        }
    }

    public float getCurrentHealth() {
        return currentHealth;
    }

    public void setWorldMap(int[,] newMap){
        worldMap = newMap;
    }

    public int[,] getWorldMap(){
        return worldMap;
    }

}
