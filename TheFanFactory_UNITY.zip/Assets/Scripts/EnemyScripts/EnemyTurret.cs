using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTurret : Enemy{

    protected float range = 20f;
    protected float fireRate = 0.4f/Global.diffMult;
    protected float fireRateFast = 8f;
    protected float fireCountdown = 0f;
    protected float fireCountdownFast = 0f;
    protected int bulletsFired = 0;
    protected int randBullets = 0;
    protected float bulletSpeed = 5f*Global.diffMult;
    [SerializeField]
    protected GameObject enemyBulletPrefab;
    [SerializeField]
    protected Transform firePoint;
    protected Vector2 direction = new Vector2(0,0);
    [SerializeField] 
    protected LayerMask wallLayer;

    // Start is called before the first frame update
    protected override void Start(){
        if(maxHealth <= 0){
            maxHealth = 5;
        }
        base.Start(); 
    }

    // Update is called once per frame
    protected virtual void Update(){

        if (player == null) return;

        float distance = Vector2.Distance(transform.position, player.position);
        if (distance <= range) {
            AimAtPlayer();
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, wallLayer);
            if (fireCountdown <= 0f && hit.collider == null) {
                if(fireCountdownFast <= 0f) {
                    if(bulletsFired == 0) {
                        randBullets = RandNumberGen.GetRandomNumber(3, 7);
                    }
                    Shoot();
                    bulletsFired++;
                    fireCountdown = 1f / fireRateFast;
                    if(bulletsFired >= randBullets) {
                        bulletsFired = 0;
                        fireCountdown = 1f / fireRate;
                    }
                }
                
            }
        }

        fireCountdown -= Time.deltaTime;
        fireCountdownFast -= Time.deltaTime;

    }

    protected void AimAtPlayer(){
        direction = (player.position - transform.position).normalized;
    }

    protected virtual void Shoot(){
        GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        float angleOffset = Random.Range(-15f, 15f);
        Vector2 noisyDirection = Quaternion.Euler(0, 0, angleOffset) * direction;
        bullet.GetComponent<Bullet>().setDirection(noisyDirection);
        bullet.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        //bullet.GetComponent<Rigidbody2D>().velocity = noisyDirection * bulletSpeed * Global.speedMult;
    }

}
