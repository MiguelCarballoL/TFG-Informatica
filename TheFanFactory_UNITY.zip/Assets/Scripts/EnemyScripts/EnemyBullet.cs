using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : Bullet
{
    private bool hasHit = false;
    protected override void OnTriggerEnter2D(Collider2D other) {
        // Comportamiento extra para balas del jugador
        if (hasHit) {
            return;
        }
        if (other.CompareTag("PlayerHitbox")) {
            PlayerController player = other.GetComponentInParent<PlayerController>();
            if (player != null && player.getInvulnerability() == false) {
                hasHit = true;
                TemperatureManager.Instance.ChangeTemperature((int)((float)(-10) * Global.diffMult));
                Destroy(gameObject);
            }
            
        }

        // Llamar a la l�gica base si quer�s que siga funcionando igual con paredes
        base.OnTriggerEnter2D(other);
    }
}
