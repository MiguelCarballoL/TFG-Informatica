using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossHealthManager : MonoBehaviour
{
    [SerializeField] 
    private Image healthFillImage;

    public void SetHealth(float current, float max) {
        float fillAmount = current / max;
        healthFillImage.fillAmount = (fillAmount * 0.86f) + 0.07f;
    }
}
