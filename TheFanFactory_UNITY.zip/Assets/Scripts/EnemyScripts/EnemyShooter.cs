using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooter : Enemy
{
    protected float speed = 1.5f;
    [SerializeField]
    protected LayerMask wallLayer;
    protected float range = 15f;
    protected float fireRate = 1f/Global.diffMult;
    protected float fireCountdown = 0f;
    protected float bulletSpeed = 10f*Global.diffMult;
    [SerializeField]
    protected GameObject enemyBulletPrefab;
    [SerializeField]
    protected Transform firePoint;
    protected Vector2 direction = new Vector2(0, 0);

    protected List<Vector2Int> currentPath;
    protected int currentPathIndex = 1;
    protected float pathUpdateTimer = 0f;
    protected float pathUpdateInterval = 0.5f;

    protected Animator animator;

    private AudioSource shooterShotSoundSource;
    // Start is called before the first frame update
    protected override void Start()
    {
        if(maxHealth <= 0){
            maxHealth = 3;
        }   
        animator = GetComponent<Animator>();
        shooterShotSoundSource = GetComponent<AudioSource>();
        base.Start();
    }

    // Update is called once per frame
    private void Update()
    {
        if (player == null) return;

        pathUpdateTimer -= Time.deltaTime;

        Vector2 rawDirection = (player.position - transform.position);
        direction = rawDirection.normalized;

        if (Mathf.Abs(rawDirection.x) > Mathf.Abs(rawDirection.y)) {
            animator.SetFloat("MoveX", Mathf.Sign(rawDirection.x));
            animator.SetFloat("MoveY", 0f);
        } else {
            animator.SetFloat("MoveX", 0f);
            animator.SetFloat("MoveY", Mathf.Sign(rawDirection.y));
        }

        float distance = Vector2.Distance(transform.position, player.position);

        if (distance <= range) {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, wallLayer);
            if (fireCountdown <= 0f && hit.collider == null) {
                Shoot();
                fireCountdown = fireRate;
            }
        }

        RaycastHit2D hitMove = Physics2D.Raycast(transform.position, direction, distance, wallLayer);

        

        if (hitMove.collider == null) {
            transform.position += (Vector3)direction * speed * Global.speedMult * Time.deltaTime;
        } else {

            if (pathUpdateTimer <= 0f) {
                Vector2Int start = new Vector2Int(Mathf.FloorToInt(transform.position.x), Mathf.FloorToInt(transform.position.y));
                Vector2Int target = new Vector2Int(Mathf.FloorToInt(player.position.x), Mathf.FloorToInt(player.position.y));

                start = PathFinding.adjustVector(worldMap, start);
                target = PathFinding.adjustVector(worldMap, target);

                currentPath = PathFinding.findPath(worldMap, start, target);
                currentPathIndex = 0;
                pathUpdateTimer = pathUpdateInterval;
            }

            if (currentPath != null && currentPathIndex < currentPath.Count) {

                Vector2 nextStep = new Vector2(
                    currentPath[currentPathIndex].x + 0.5f,
                    currentPath[currentPathIndex].y + 0.5f
                );
                Vector2 toNext = nextStep - (Vector2)transform.position;

                if (toNext.magnitude < 0.5f) {
                    currentPathIndex++; // Avanzamos al siguiente nodo
                } else {
                    Vector2 moveDir = toNext.normalized;
                    transform.position = Vector2.MoveTowards(
                        transform.position,
                        nextStep,
                        speed * Global.speedMult * Time.deltaTime
                    );
                }
            }
        }

        fireCountdown -= Time.deltaTime;
    }

    protected virtual void Shoot() {
        shooterShotSoundSource.Play();
        GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
        bullet.GetComponent<Bullet>().setDirection(direction);
        bullet.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        //bullet.GetComponent<Rigidbody2D>().velocity = noisyDirection * bulletSpeed * Global.speedMult;
    }
}
