using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyChaserSpeed : EnemyChaser{

    private float speedTimer = 3f;
    private float speedInterval = 3f;
    private float speedUp = 0.5f;

    // Start is called before the first frame update
    protected override void Start() {
        maxHealth = 4;
        speed = 2.5f * Global.diffMult;
        base.Start();
    }

    // Update is called once per frame
    protected override void Update()
    {
        base.Update();

        if(speedTimer <= 0f && speed <= 8f) {
            speed += speedUp;
            speedTimer = speedInterval;
        }

        speedTimer -= Time.deltaTime;
    }
    
}
