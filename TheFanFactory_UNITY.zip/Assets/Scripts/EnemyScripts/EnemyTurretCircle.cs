using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTurretCircle : EnemyTurret{

    private AudioSource turretCircleShotSoundSource;

    // Start is called before the first frame update
    protected override void Start(){
        maxHealth = 6;
        range = 20f;
        bulletSpeed = 5f * Global.diffMult;
        fireRate = 0.4f / Global.diffMult;
        turretCircleShotSoundSource = GetComponent<AudioSource>();
        base.Start(); 
    }

    // Update is called once per frame
    protected override void Update(){

        if (player == null) return;

        float distance = Vector2.Distance(transform.position, player.position);
        if (distance <= range) {
            AimAtPlayer();
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distance, wallLayer);
            if (fireCountdown <= 0f && hit.collider == null) {
                Shoot();
                fireCountdown = 1f / fireRate;
            }
        }

        fireCountdown -= Time.deltaTime;

    }

    protected override void Shoot() {
        turretCircleShotSoundSource.Play();
        for (int i = 0; i < 36; i++) {
            GameObject bullet = Instantiate(enemyBulletPrefab, firePoint.position, Quaternion.identity);
            float angleOffset = 0 + 10f * i;
            Vector2 noisyDirection = Quaternion.Euler(0, 0, angleOffset) * direction;
            bullet.GetComponent<Bullet>().setDirection(noisyDirection);
            bullet.GetComponent<Bullet>().setBaseSpeed(bulletSpeed);
        }
    }

}
