using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TemperatureManager : MonoBehaviour{

    private int temperature = 20;
    [SerializeField]
    private TextMeshProUGUI temperatureText;
    public static TemperatureManager Instance;
    private float invulnerabilityTime = 1.5f;
    private float lastHitTime = 0f;
    private int tempThreshold = -40;
    private PlayerController player;
    
    [SerializeField]
    private GameOverMenu gameOverController;

    [SerializeField]
    private ProceduralGen procGen;
    [SerializeField]
    private TilemapGenerator tilemapGenerator;

    // Start is called before the first frame update
    private void Start(){
        UpdateTemperatureUI();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>();
    }

    private void Update() {
        lastHitTime -= Time.deltaTime;
    }

    public void ChangeTemperature(int amount) {

        if(amount < 0){
            amount = (int)((float)amount * Global.diffMult);
        } else if(Global.diffMult <= 1){
            amount = (int)((float)amount / Global.diffMult);
        }

        if(amount < 0){
            if(player.getInvulnerability() == false){
                if(lastHitTime <= 0f) {
                    temperature += amount;
                    if(temperature < -273) {
                        temperature = -273;
                    }
                    UpdateTemperatureUI();
                    lastHitTime = invulnerabilityTime;
                    Global.hitsTaken++;
                    player.TakeDamage();
                    if(temperature <= tempThreshold) {
                        procGen.saveDataFunc();
                        gameOverController.gameOver();
                    }
                }
            }
        }else{
            temperature += amount;
            UpdateTemperatureUI();
        }

    }

    public int getTemperature() {
        return temperature;
    }

    private void UpdateTemperatureUI() {

        temperatureText.text = temperature.ToString()+" �C";

        if(temperature <= 0){
            tilemapGenerator.setFloorTileMap();
            temperatureText.color = Color.blue;
        }else if(temperature <= 20){
            tilemapGenerator.setFloorTileMap();
            temperatureText.color = Color.white;
        }else if(temperature <= 40){
            tilemapGenerator.setFloorTileMap();
            temperatureText.color = Color.yellow;
        }else if(temperature <= 70){
            tilemapGenerator.setFloorTileMap();
            temperatureText.color = new Color(1f, 0.5f, 0f);
        }else{
            tilemapGenerator.setFloorTileMap();
            temperatureText.color = Color.red;
        }

        if(temperature <= -273){
            Global.speedMult = 0f;
        }else if(temperature <= -100){
            Global.speedMult = (float)temperature * 0.001445f + 0.394485f;
        }else if(temperature <= -20){
            Global.speedMult = (float)temperature * 0.003125f + 0.5625f;
        }else if(temperature <= 20){
            Global.speedMult = (float)temperature * 0.0125f + 0.75f;
        }else if(temperature <= 100){
            Global.speedMult = (float)temperature * 0.0125f + 0.75f;
        }else if(temperature <= 250){
            Global.speedMult = (float)temperature * 0.006667f + 1.3333f;
        }else if(temperature <= 1000){
            Global.speedMult = (float)temperature * 0.001333f + 2.667f;
        }else{
            Global.speedMult = 4f;
        }

    }

    public void Awake() {
        Instance = this;
    }

    public void setTempThreshold(int newThreshold) {
        tempThreshold = newThreshold;
    }

    public int getTempThreshold() {
        return tempThreshold;
    }

}
